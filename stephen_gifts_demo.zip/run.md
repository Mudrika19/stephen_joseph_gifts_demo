Sub domains:

- India <http://in.localhost:3000>
- French <http://fr.localhost:3000>
- US <http://us.localhost:3000>
